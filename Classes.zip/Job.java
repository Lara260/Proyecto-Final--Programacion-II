package Classes;

import java.util.ArrayList;
import java.util.List;

// Job.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Jobs en la base de datos.
 */
public class Job {
    // Campos correspondientes a la tabla Jobs en la base de datos
    private int job_id;
    private String job_desc;
    private int min_lvl;
    private int max_lvl;
    
    // Constructor
    public Job(int job_id, String job_desc, int min_lvl, int max_lvl) {
        this.job_id = job_id;
        this.job_desc = job_desc;
        this.min_lvl = min_lvl;
        this.max_lvl = max_lvl;
    }
    
    // Getters y Setters
    public int getJob_id() {
        return job_id;
    }

    public void setJob_id(int job_id) {
        this.job_id = job_id;
    }

    public String getJob_desc() {
        return job_desc;
    }

    public void setJob_desc(String job_desc) {
        this.job_desc = job_desc;
    }

    public int getMin_lvl() {
        return min_lvl;
    }

    public void setMin_lvl(int min_lvl) {
        this.min_lvl = min_lvl;
    }

    public int getMax_lvl() {
        return max_lvl;
    }

    public void setMax_lvl(int max_lvl) {
        this.max_lvl = max_lvl;
    }

    // ArrayList para almacenar los puestos de trabajo
    private static List<Job> jobs = new ArrayList<>();

    // Método para crear un nuevo puesto de trabajo
    public static void createJob(Job job) {
        jobs.add(job);
    }

    // Método para obtener un puesto de trabajo por su ID
    public static Job getJobById(int job_id) {
        for (Job job : jobs) {
            if (job.getJob_id() == job_id) {
                return job;
            }
        }
        return null; // Si no se encuentra el puesto de trabajo
    }

    // Método para actualizar un puesto de trabajo existente
    public static void updateJob(Job updatedJob) {
        for (int i = 0; i < jobs.size(); i++) {
            if (jobs.get(i).getJob_id() == updatedJob.getJob_id()) {
                jobs.set(i, updatedJob);
                return;
            }
        }
    }

    // Método para eliminar un puesto de trabajo por su ID
    public static void deleteJobById(int job_id) {
        jobs.removeIf(job -> job.getJob_id() == job_id);
    }

}
