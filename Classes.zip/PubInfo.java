package Classes;

import java.util.ArrayList;
import java.util.List;

// PubInfo.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Pub_Info en la base de datos.
 */
public class PubInfo {
    // Campos correspondientes a la tabla Pub_Info en la base de datos
    private String pub_id;
    private byte[] lo;
    private String pr_info;
    
    // Constructor
    public PubInfo(String pub_id, byte[] lo, String pr_info) {
        this.pub_id = pub_id;
        this.lo = lo;
        this.pr_info = pr_info;
    }
    
    // Getters y Setters
    public String getPub_id() {
        return pub_id;
    }

    public void setPub_id(String pub_id) {
        this.pub_id = pub_id;
    }

    public byte[] getLo() {
        return lo;
    }

    public void setLo(byte[] lo) {
        this.lo = lo;
    }

    public String getPr_info() {
        return pr_info;
    }

    public void setPr_info(String pr_info) {
        this.pr_info = pr_info;
    }


    // ArrayList para almacenar la información de las publicaciones
    private static List<PubInfo> pubInfos = new ArrayList<>();

    // Método para crear una nueva publicación
    public static void createPubInfo(PubInfo pubInfo) {
        pubInfos.add(pubInfo);
    }

    // Método para obtener la información de una publicación por su ID
    public static PubInfo getPubInfoById(String pub_id) {
        for (PubInfo pubInfo : pubInfos) {
            if (pubInfo.getPub_id().equals(pub_id)) {
                return pubInfo;
            }
        }
        return null; // Si no se encuentra la publicación
    }

    // Método para actualizar la información de una publicación existente
    public static void updatePubInfo(PubInfo updatedPubInfo) {
        for (int i = 0; i < pubInfos.size(); i++) {
            if (pubInfos.get(i).getPub_id().equals(updatedPubInfo.getPub_id())) {
                pubInfos.set(i, updatedPubInfo);
                return;
            }
        }
    }

    // Método para eliminar la información de una publicación por su ID
    public static void deletePubInfoById(String pub_id) {
        pubInfos.removeIf(pubInfo -> pubInfo.getPub_id().equals(pub_id));
    }

}
