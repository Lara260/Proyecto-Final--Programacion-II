package Classes;

import java.util.ArrayList;
import java.util.List;

// RoySched.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Roysched en la base de datos.
 */
public class RoySched {
    // Campos correspondientes a la tabla Roysched en la base de datos
    private String title_id;
    private int lorange;
    private int hirange;
    private int royalty;
    
    // Constructor
    public RoySched(String title_id, int lorange, int hirange, int royalty) {
        this.title_id = title_id;
        this.lorange = lorange;
        this.hirange = hirange;
        this.royalty = royalty;
    }
    
    // Getters y Setters
    public String getTitle_id() {
        return title_id;
    }

    public void setTitle_id(String title_id) {
        this.title_id = title_id;
    }

    public int getLorange() {
        return lorange;
    }

    public void setLorange(int lorange) {
        this.lorange = lorange;
    }

    public int getHirange() {
        return hirange;
    }

    public void setHirange(int hirange) {
        this.hirange = hirange;
    }

    public int getRoyalty() {
        return royalty;
    }

    public void setRoyalty(int royalty) {
        this.royalty = royalty;
    }

        private static List<RoySched> royscheds = new ArrayList<>();

    // Método para crear un nuevo registro de royalties
    public static void createRoysched(RoySched roysched) {
        royscheds.add(roysched);
    }

    // Método para obtener un registro de royalties por su título
    public static RoySched getRoyschedByTitleId(String title_id) {
        for (RoySched roysched : royscheds) {
            if (roysched.getTitle_id().equals(title_id)) {
                return roysched;
            }
        }
        return null; // Si no se encuentra el registro de royalties
    }

    // Método para actualizar un registro de royalties existente
    public static void updateRoysched(RoySched updatedRoysched) {
        for (int i = 0; i < royscheds.size(); i++) {
            if (royscheds.get(i).getTitle_id().equals(updatedRoysched.getTitle_id())) {
                royscheds.set(i, updatedRoysched);
                return;
            }
        }
    }

    // Método para eliminar un registro de royalties por su título
    public static void deleteRoyschedByTitleId(String title_id) {
        royscheds.removeIf(roysched -> roysched.getTitle_id().equals(title_id));
    }
    
}
