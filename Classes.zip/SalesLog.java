package Classes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// SalesLog.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Sales_Log en la base de datos.
 */
public class SalesLog {
    // Campos correspondientes a la tabla Sales_Log en la base de datos
    private int sales_log_id;
    private String stor_id;
    private String order_num;
    private String title_id;
    private String au_id;
    private Date log_date;
    private BigDecimal price;
    private int quantity;
    
    // Constructor
    public SalesLog(int sales_log_id, String stor_id, String order_num, String title_id, String au_id, Date log_date, BigDecimal price, int quantity) {
        this.sales_log_id = sales_log_id;
        this.stor_id = stor_id;
        this.order_num = order_num;
        this.title_id = title_id;
        this.au_id = au_id;
        this.log_date = log_date;
        this.price = price;
        this.quantity = quantity;
    }
    
    // Getters y Setters
    public int getSales_log_id() {
        return sales_log_id;
    }

    public void setSales_log_id(int sales_log_id) {
        this.sales_log_id = sales_log_id;
    }

    public String getStor_id() {
        return stor_id;
    }

    public void setStor_id(String stor_id) {
        this.stor_id = stor_id;
    }

    public String getOrder_num() {
        return order_num;
    }

    public void setOrder_num(String order_num) {
        this.order_num = order_num;
    }

    public String getTitle_id() {
        return title_id;
    }

    public void setTitle_id(String title_id) {
        this.title_id = title_id;
    }

    public String getAu_id() {
        return au_id;
    }

    public void setAu_id(String au_id) {
        this.au_id = au_id;
    }

    public Date getLog_date() {
        return log_date;
    }

    public void setLog_date(Date log_date) {
        this.log_date = log_date;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    // ArrayList para almacenar los registros de ventas
    private static List<SalesLog> salesLogs = new ArrayList<>();

    // Método para crear un nuevo registro de ventas
    public static void createSalesLog(SalesLog salesLog) {
        salesLogs.add(salesLog);
    }

    // Método para obtener un registro de ventas por su ID
    public static SalesLog getSalesLogById(int sales_log_id) {
        for (SalesLog salesLog : salesLogs) {
            if (salesLog.getSales_log_id() == sales_log_id) {
                return salesLog;
            }
        }
        return null; // Si no se encuentra el registro de ventas
    }

    // Método para actualizar un registro de ventas existente
    public static void updateSalesLog(SalesLog updatedSalesLog) {
        for (int i = 0; i < salesLogs.size(); i++) {
            if (salesLogs.get(i).getSales_log_id() == updatedSalesLog.getSales_log_id()) {
                salesLogs.set(i, updatedSalesLog);
                return;
            }
        }
    }

    // Método para eliminar un registro de ventas por su ID
    public static void deleteSalesLogById(int sales_log_id) {
        salesLogs.removeIf(salesLog -> salesLog.getSales_log_id() == sales_log_id);
    }
}

