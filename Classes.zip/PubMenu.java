package Classes;

import java.util.ArrayList;
import java.util.List;

// PubMenu.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Pub_Menu en la base de datos.
 */
public class PubMenu {
    // Campos correspondientes a la tabla Pub_Menu en la base de datos
    private int mnu_num;
    private Integer mnu_master;
    private String mnu_name;
    
    // Constructor
    public PubMenu(int mnu_num, Integer mnu_master, String mnu_name) {
        this.mnu_num = mnu_num;
        this.mnu_master = mnu_master;
        this.mnu_name = mnu_name;
    }
    
    // Getters y Setters
    public int getMnu_num() {
        return mnu_num;
    }

    public void setMnu_num(int mnu_num) {
        this.mnu_num = mnu_num;
    }

    public Integer getMnu_master() {
        return mnu_master;
    }

    public void setMnu_master(Integer mnu_master) {
        this.mnu_master = mnu_master;
    }

    public String getMnu_name() {
        return mnu_name;
    }

    public void setMnu_name(String mnu_name) {
        this.mnu_name = mnu_name;
    }
    
    // ArrayList para almacenar los menús de publicación
    private static List<PubMenu> pubMenus = new ArrayList<>();

    // Método para crear un nuevo menú de publicación
    public static void createPubMenu(PubMenu pubMenu) {
        pubMenus.add(pubMenu);
    }

    // Método para obtener un menú de publicación por su número
    public static PubMenu getPubMenuByNumber(int mnu_num) {
        for (PubMenu pubMenu : pubMenus) {
            if (pubMenu.getMnu_num() == mnu_num) {
                return pubMenu;
            }
        }
        return null; // Si no se encuentra el menú de publicación
    }

    // Método para actualizar un menú de publicación existente
    public static void updatePubMenu(PubMenu updatedPubMenu) {
        for (int i = 0; i < pubMenus.size(); i++) {
            if (pubMenus.get(i).getMnu_num() == updatedPubMenu.getMnu_num()) {
                pubMenus.set(i, updatedPubMenu);
                return;
            }
        }
    }

    // Método para eliminar un menú de publicación por su número
    public static void deletePubMenuByNumber(int mnu_num) {
        pubMenus.removeIf(pubMenu -> pubMenu.getMnu_num() == mnu_num);
    }
}

