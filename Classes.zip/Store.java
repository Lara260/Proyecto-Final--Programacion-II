package Classes;

import java.util.ArrayList;
import java.util.List;

// Store.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Stores en la base de datos.
 */
public class Store {
    // Campos correspondientes a la tabla Stores en la base de datos
    private String stor_id;
    private String stor_name;
    private String stor_address;
    private String city;
    private String state;
    private String zip;
    
    // Constructor
    public Store(String stor_id, String stor_name, String stor_address, String city, String state, String zip) {
        this.stor_id = stor_id;
        this.stor_name = stor_name;
        this.stor_address = stor_address;
        this.city = city;
        this.state = state;
        this.zip = zip;
    }
    
    // Getters y Setters
    public String getStor_id() {
        return stor_id;
    }

    public void setStor_id(String stor_id) {
        this.stor_id = stor_id;
    }

    public String getStor_name() {
        return stor_name;
    }

    public void setStor_name(String stor_name) {
        this.stor_name = stor_name;
    }

    public String getStor_address() {
        return stor_address;
    }

    public void setStor_address(String stor_address) {
        this.stor_address = stor_address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }


    // ArrayList para almacenar las tiendas
    private static List<Store> stores = new ArrayList<>();

    // Método para crear una nueva tienda
    public static void createStore(Store store) {
        stores.add(store);
    }

    // Método para obtener una tienda por su ID
    public static Store getStoreById(String stor_id) {
        for (Store store : stores) {
            if (store.getStor_id().equals(stor_id)) {
                return store;
            }
        }
        return null; // Si no se encuentra la tienda
    }

    // Método para actualizar una tienda existente
    public static void updateStore(Store updatedStore) {
        for (int i = 0; i < stores.size(); i++) {
            if (stores.get(i).getStor_id().equals(updatedStore.getStor_id())) {
                stores.set(i, updatedStore);
                return;
            }
        }
    }

    // Método para eliminar una tienda por su ID
    public static void deleteStoreById(String stor_id) {
        stores.removeIf(store -> store.getStor_id().equals(stor_id));
    }

}
