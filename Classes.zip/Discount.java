package Classes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

// Discount.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Discounts en la base de datos.
 */
public class Discount {
    // Campos correspondientes a la tabla Discounts en la base de datos
    private String discountype;
    private String stor_id;
    private Integer lowqty;
    private Integer highqty;
    private BigDecimal discount;
    
    // Constructor
    public Discount(String discountype, String stor_id, Integer lowqty, Integer highqty, BigDecimal discount) {
        this.discountype = discountype;
        this.stor_id = stor_id;
        this.lowqty = lowqty;
        this.highqty = highqty;
        this.discount = discount;
    }
    
    // Getters y Setters
    public String getDiscountype() {
        return discountype;
    }

    public void setDiscountype(String discountype) {
        this.discountype = discountype;
    }

    public String getStor_id() {
        return stor_id;
    }

    public void setStor_id(String stor_id) {
        this.stor_id = stor_id;
    }

    public Integer getLowqty() {
        return lowqty;
    }

    public void setLowqty(Integer lowqty) {
        this.lowqty = lowqty;
    }

    public Integer getHighqty() {
        return highqty;
    }

    public void setHighqty(Integer highqty) {
        this.highqty = highqty;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }
    private static List<Discount> discounts = new ArrayList<>();

    // Método para crear un nuevo descuento
    public static void createDiscount(Discount discount) {
        discounts.add(discount);
    }

    // Método para obtener un descuento por su tipo y tienda
    public static Discount getDiscountByTypeAndStore(String discountype, String stor_id) {
        for (Discount discount : discounts) {
            if (discount.getDiscountype().equals(discountype) && discount.getStor_id().equals(stor_id)) {
                return discount;
            }
        }
        return null; // Si no se encuentra el descuento
    }

    // Método para actualizar un descuento existente
    public static void updateDiscount(Discount updatedDiscount) {
        for (int i = 0; i < discounts.size(); i++) {
            Discount discount = discounts.get(i);
            if (discount.getDiscountype().equals(updatedDiscount.getDiscountype()) && discount.getStor_id().equals(updatedDiscount.getStor_id())) {
                discounts.set(i, updatedDiscount);
                return;
            }
        }
    }

    // Método para eliminar un descuento por su tipo y tienda
    public static void deleteDiscountByTypeAndStore(String discountype, String stor_id) {
        discounts.removeIf(discount -> discount.getDiscountype().equals(discountype) && discount.getStor_id().equals(stor_id));
    }
    
}

