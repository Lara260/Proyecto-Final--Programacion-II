package Classes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// Sale.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Sales en la base de datos.
 */
public class Sale {
    // Campos correspondientes a la tabla Sales en la base de datos
    private String stor_id;
    private String order_num;
    private Date ord_date;
    private int qty;
    private String payterms;
    private String title_id;
    
    // Constructor
    public Sale(String stor_id, String order_num, Date ord_date, int qty, String payterms, String title_id) {
        this.stor_id = stor_id;
        this.order_num = order_num;
        this.ord_date = ord_date;
        this.qty = qty;
        this.payterms = payterms;
        this.title_id = title_id;
    }
    
    // Getters y Setters
    public String getStor_id() {
        return stor_id;
    }

    public void setStor_id(String stor_id) {
        this.stor_id = stor_id;
    }

    public String getOrder_num() {
        return order_num;
    }

    public void setOrder_num(String order_num) {
        this.order_num = order_num;
    }

    public Date getOrd_date() {
        return ord_date;
    }

    public void setOrd_date(Date ord_date) {
        this.ord_date = ord_date;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getPayterms() {
        return payterms;
    }

    public void setPayterms(String payterms) {
        this.payterms = payterms;
    }

    public String getTitle_id() {
        return title_id;
    }

    public void setTitle_id(String title_id) {
        this.title_id = title_id;
    }
    // ArrayList para almacenar las ventas
    private static List<Sale> sales = new ArrayList<>();

    // Método para crear una nueva venta
    public static void createSale(Sale sale) {
        sales.add(sale);
    }

    // Método para obtener una venta por su número de orden
    public static Sale getSaleByOrderNumber(String order_num) {
        for (Sale sale : sales) {
            if (sale.getOrder_num().equals(order_num)) {
                return sale;
            }
        }
        return null; // Si no se encuentra la venta
    }

    // Método para actualizar una venta existente
    public static void updateSale(Sale updatedSale) {
        for (int i = 0; i < sales.size(); i++) {
            if (sales.get(i).getOrder_num().equals(updatedSale.getOrder_num())) {
                sales.set(i, updatedSale);
                return;
            }
        }
    }

    // Método para eliminar una venta por su número de orden
    public static void deleteSaleByOrderNumber(String order_num) {
        sales.removeIf(sale -> sale.getOrder_num().equals(order_num));
    }
    
}
