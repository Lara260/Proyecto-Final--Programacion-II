package Classes;

import java.util.ArrayList;
import java.util.List;

// Author.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Authors en la base de datos.
 */
public class Author {
    // Campos correspondientes a la tabla Authors en la base de datos
    private String au_id;
    private String au_lname;
    private String au_fname;
    private String phone;
    private String address;
    private String city;
    private String state;
    private String zip;
    private boolean contract;
    
    // Constructor
    public Author(String au_id, String au_lname, String au_fname, String phone, String address, String city, String state, String zip, boolean contract) {
        this.au_id = au_id;
        this.au_lname = au_lname;
        this.au_fname = au_fname;
        this.phone = phone;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.contract = contract;
    }
    
    // Getters y Setters
    public String getAu_id() {
        return au_id;
    }

    public void setAu_id(String au_id) {
        this.au_id = au_id;
    }

    public String getAu_lname() {
        return au_lname;
    }

    public void setAu_lname(String au_lname) {
        this.au_lname = au_lname;
    }

    public String getAu_fname() {
        return au_fname;
    }

    public void setAu_fname(String au_fname) {
        this.au_fname = au_fname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public boolean isContract() {
        return contract;
    }

    public void setContract(boolean contract) {
        this.contract = contract;
    }

    // ArrayList para almacenar los autores
    private static List<Author> authors = new ArrayList<>();

    // Método para crear un nuevo autor
    public static void createAuthor(Author author) {
        authors.add(author);
    }

    // Método para obtener un autor por su ID
    public static Author getAuthorById(String au_id) {
        for (Author author : authors) {
            if (author.getAu_id().equals(au_id)) {
                return author;
            }
        }
        return null; // Si no se encuentra el autor
    }

    // Método para actualizar un autor existente
    public static void updateAuthor(Author updatedAuthor) {
        for (int i = 0; i < authors.size(); i++) {
            if (authors.get(i).getAu_id().equals(updatedAuthor.getAu_id())) {
                authors.set(i, updatedAuthor);
                return;
            }
        }
    }

    // Método para eliminar un autor por su ID
    public static void deleteAuthorById(String au_id) {
        authors.removeIf(author -> author.getAu_id().equals(au_id));
    }
}


