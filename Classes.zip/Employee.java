package Classes;

import java.util.ArrayList;
import java.util.List;

/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Employee en la base de datos.
 */
public class Employee {
    // Campos correspondientes a la tabla Employee en la base de datos
    private String emp_id;
    private String fname;
    private String minit;
    private String lname;
    private String job_id;
    private String job_lvl;
    private String pub_id;
    private String hire_date;
    
    // Constructor
    public Employee(String emp_id, String fname, String minit, String lname, String job_id, String job_lvl, String pub_id, String hire_date) {
        this.emp_id = emp_id;
        this.fname = fname;
        this.minit = minit;
        this.lname = lname;
        this.job_id = job_id;
        this.job_lvl = job_lvl;
        this.pub_id = pub_id;
        this.hire_date = hire_date;
    }
    
    // Getters y Setters
    public String getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(String emp_id) {
        this.emp_id = emp_id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getMinit() {
        return minit;
    }

    public void setMinit(String minit) {
        this.minit = minit;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getJob_id() {
        return job_id;
    }

    public String setJob_id(String job_id) {
        return this.job_id = job_id;
    }

    public String getJob_lvl() {
        return job_lvl;
    }

    public void setJob_lvl(String job_lvl) {
        this.job_lvl = job_lvl;
    }

    public String getPub_id() {
        return pub_id;
    }

    public void setPub_id(String pub_id) {
        this.pub_id = pub_id;
    }

    public String getHire_date() {
        return hire_date;
    }

    public void setHire_date(String hire_date) {
        this.hire_date = hire_date;
    }

    // ArrayList para almacenar los empleados
    private static List<Employee> employees = new ArrayList<>();

    // Método para crear un nuevo empleado
    public static void createEmployee(Employee employee) {
        employees.add(employee);
    }

    // Método para obtener un empleado por su ID
    public static Employee getEmployeeById(String emp_id) {
        for (Employee employee : employees) {
            if (employee.getEmp_id() == emp_id) {
                return employee;
            }
        }
        return null; // Si no se encuentra el empleado
    }

    // Método para actualizar un empleado existente
    public static void updateEmployee(Employee updatedEmployee) {
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getEmp_id() == updatedEmployee.getEmp_id()) {
                employees.set(i, updatedEmployee);
                return;
            }
        }
    }

    // Método para eliminar un empleado por su ID
    public static void deleteEmployeeById(String emp_id) {
        employees.removeIf(employee -> employee.getEmp_id() == emp_id);
    }

}
