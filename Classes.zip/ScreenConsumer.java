package Classes;

import java.util.Scanner;
// ScreenConsumer.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa el frontend del projecto.
 */
public class ScreenConsumer {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int actionChoice;

        do {
            System.out.println("Seleccione la acción que desea realizar:");
            System.out.println("1. Crear un registro");
            System.out.println("2. Leer un registro");
            System.out.println("3. Actualizar un registro");
            System.out.println("4. Eliminar un registro");
            System.out.println("5. Salir");
            System.out.print("Opción: ");
            actionChoice = scanner.nextInt();

            switch (actionChoice) {
                case 1:
                    printTableOptions();
                    actionChoice = scanner.nextInt();
                    switch (actionChoice) {
                        case 1:
                            createPublisher();
                            break;
                        case 2:
                            createEmployee();
                            default:
                            break;
                    }
                    // Lógica para crear un registro
                    break;
                case 2:
                    System.out.println("Seleccione la tabla:");
                    printTableOptions();
                    actionChoice = scanner.nextInt();
                    switch (actionChoice) {
                        case 1:
                            getPublisher();
                            break;
                        case 2:
                            getEmploye();                    
                            default:
                            break;
                    }
                    break;
                case 3:
                    System.out.println("Seleccione la tabla:");
                    printTableOptions();

                case 4:
                    System.out.println("Seleccione la tabla:");
                    printTableOptions();
                    actionChoice = scanner.nextInt();
                    switch (actionChoice) {
                        case 1:
                            deletePublisher();
                            break;
                        case 2:
                            deleteEmployeeById();
                            default:
                            break;
                    }
                    break;
                case 5:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
            }
        } while (actionChoice != 5);

        scanner.close();
    }

    private static void createPublisher() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el ID del publisher:");
        String pub_id = scanner.nextLine();
        System.out.println("Ingrese el nombre del publisher:");
        String pub_name = scanner.nextLine();
        System.out.println("Ingrese la ciudad del publisher:");
        String city = scanner.nextLine();
        System.out.println("Ingrese el estado del publisher:");
        String state = scanner.nextLine();
        System.out.println("Ingrese el país del publisher:");
        String country = scanner.nextLine();

        Publisher publisher = new Publisher(pub_id, pub_name, city, state, country);

        Publisher.createPublisher(publisher);
        System.out.println("publisher creado con éxito.");
    }

    private static void getPublisher() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el ID del publisher:");
        String pub_id = scanner.nextLine();

        System.out.println(getPublisherInfoById(pub_id));
    }

    public static String getPublisherInfoById(String pub_id) {
        Publisher publisher = Publisher.getPublisherById(pub_id);
        if (publisher != null) {
            return "ID: " + publisher.getPub_id() + ", Nombre: " + publisher.getPub_name() + ", Dirección: " + publisher.getCity(); // y así sucesivamente con los atributos relevantes
        } else {
            return "El publisher no se encontró";
        }
    }

    private static void deletePublisher() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el ID del publisher:");
        String pub_id = scanner.nextLine();

        Publisher.deletePublisherById(pub_id);

        System.out.println("Se ha elimiando el publisher");
    }

    private static void createEmployee() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el ID del Empleado:");
        String emp_id = scanner.nextLine();
        System.out.println("Ingrese el nombre del Empleado:");
        String fname = scanner.nextLine();
        System.out.println("Ingrese la minint del Empleado:");
        String minit = scanner.nextLine();
        System.out.println("Ingrese el apellido del Empleado:");
        String lname = scanner.nextLine();
        System.out.println("Ingrese el jobid del Empleado:");
        String job_id = scanner.nextLine();
        System.out.println("Ingrese el joblevel del Empleado:");
        String job_lvl = scanner.nextLine();
        System.out.println("Ingrese el publisherid del Empleado:");
        String pub_id = scanner.nextLine();
        System.out.println("Ingrese el la fecha de ingreso del Empleado:");
        String hire_date = scanner.nextLine();

        Employee employee = new Employee(emp_id, fname, minit, lname, job_id, job_lvl, pub_id, hire_date);

        Employee.createEmployee(employee);
        System.out.println("Empleado creado con éxito.");
    }

    private static void getEmploye() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el ID del empleado:");
        String empid = scanner.nextLine();

        System.out.println(getEmployeeInfoById(empid));
    }

    public static String getEmployeeInfoById(String empid) {
        Employee employee = Employee.getEmployeeById(empid);
        if (employee != null) {
            return "ID: " + employee.getPub_id() + ", Nombre: " + employee.getFname() + ", Apellido: " + employee.getLname(); // y así sucesivamente con los atributos relevantes
        } else {
            return "El empleado no se encontró";
        }
    }

    private static void deleteEmployeeById() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el ID del empleado:");
        String empid = scanner.nextLine();

        Employee.deleteEmployeeById(empid);

        System.out.println("Se ha elimiando el empleado");
    }

    private static void printTableOptions() {
        System.out.println("Seleccione la tabla:");
        System.out.println("1. Publishers");
        System.out.println("2. Employee");
        System.out.println("3. Jobs");
        System.out.println("4. Pub_Info");
        System.out.println("5. Titles");
        System.out.println("6. Roysched");
        System.out.println("7. Authors");
        System.out.println("8. Title_Author");
        System.out.println("9. Stores");
        System.out.println("10. Sales");
        System.out.println("11. Sales_Log");
        System.out.println("12. Discounts");
        System.out.println("13. Pub_Menu");
    }

}
