package Classes;

import java.util.ArrayList;
import java.util.List;

// Publisher.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Publisher en la base de datos.
 */
public class Publisher {
    // Campos correspondientes a la tabla Publishers en la base de datos
    private String pub_id;
    private String pub_name;
    private String city;
    private String state;
    private String country;
    
    // Constructor
    public Publisher(String pub_id, String pub_name, String city, String state, String country) {
        this.pub_id = pub_id;
        this.pub_name = pub_name;
        this.city = city;
        this.state = state;
        this.country = country;
    }
    
    // Getters y Setters
    public String getPub_id() {
        return pub_id;
    }

    public void setPub_id(String pub_id) {
        this.pub_id = pub_id;
    }

    public String getPub_name() {
        return pub_name;
    }

    public void setPub_name(String pub_name) {
        this.pub_name = pub_name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    // ArrayList para almacenar los editores
    private static List<Publisher> publishers = new ArrayList<>();

    // Método para crear un nuevo editor
    public static void createPublisher(Publisher publisher) {
        publishers.add(publisher);
    }

    // Método para obtener un editor por su ID
    public static Publisher getPublisherById(String pub_id) {
        for (Publisher publisher : publishers) {
            if (publisher.getPub_id().equals(pub_id)) {
                return publisher;
            }
        }
        return null; // Si no se encuentra el editor
    }

    // Método para actualizar un editor existente
    public static void updatePublisher(Publisher updatedPublisher) {
        for (int i = 0; i < publishers.size(); i++) {
            if (publishers.get(i).getPub_id().equals(updatedPublisher.getPub_id())) {
                publishers.set(i, updatedPublisher);
                return;
            }
        }
    }

    // Método para eliminar un editor por su ID
    public static void deletePublisherById(String pub_id) {
        publishers.removeIf(publisher -> publisher.getPub_id().equals(pub_id));
    }

}
