package Classes;

import java.util.ArrayList;
import java.util.List;

// TitleAuthor.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Title_Author en la base de datos.
 */
public class TitleAuthor {
    // Campos correspondientes a la tabla Title_Author en la base de datos
    private String title_id;
    private String au_id;
    private int au_ord;
    private int royaltytyper;
    
    // Constructor
    public TitleAuthor(String title_id, String au_id, int au_ord, int royaltytyper) {
        this.title_id = title_id;
        this.au_id = au_id;
        this.au_ord = au_ord;
        this.royaltytyper = royaltytyper;
    }
    
    // Getters y Setters
    public String getTitle_id() {
        return title_id;
    }

    public void setTitle_id(String title_id) {
        this.title_id = title_id;
    }

    public String getAu_id() {
        return au_id;
    }

    public void setAu_id(String au_id) {
        this.au_id = au_id;
    }

    public int getAu_ord() {
        return au_ord;
    }

    public void setAu_ord(int au_ord) {
        this.au_ord = au_ord;
    }

    public int getRoyaltytyper() {
        return royaltytyper;
    }

    public void setRoyaltytyper(int royaltytyper) {
        this.royaltytyper = royaltytyper;
    }
    // ArrayList para almacenar los registros de relación entre títulos y autores
    private static List<TitleAuthor> titleAuthors = new ArrayList<>();

    // Método para crear un nuevo registro de relación entre título y autor
    public static void createTitleAuthor(TitleAuthor titleAuthor) {
        titleAuthors.add(titleAuthor);
    }

    // Método para obtener un registro de relación entre título y autor por su título y autor
    public static TitleAuthor getTitleAuthorByTitleAndAuthor(String title_id, String au_id) {
        for (TitleAuthor titleAuthor : titleAuthors) {
            if (titleAuthor.getTitle_id().equals(title_id) && titleAuthor.getAu_id().equals(au_id)) {
                return titleAuthor;
            }
        }
        return null; // Si no se encuentra el registro de relación
    }

    // Método para actualizar un registro de relación entre título y autor existente
    public static void updateTitleAuthor(TitleAuthor updatedTitleAuthor) {
        for (int i = 0; i < titleAuthors.size(); i++) {
            TitleAuthor titleAuthor = titleAuthors.get(i);
            if (titleAuthor.getTitle_id().equals(updatedTitleAuthor.getTitle_id()) && titleAuthor.getAu_id().equals(updatedTitleAuthor.getAu_id())) {
                titleAuthors.set(i, updatedTitleAuthor);
                return;
            }
        }
    }

    // Método para eliminar un registro de relación entre título y autor por su título y autor
    public static void deleteTitleAuthorByTitleAndAuthor(String title_id, String au_id) {
        titleAuthors.removeIf(titleAuthor -> titleAuthor.getTitle_id().equals(title_id) && titleAuthor.getAu_id().equals(au_id));
    }

}
