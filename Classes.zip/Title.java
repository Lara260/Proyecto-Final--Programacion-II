package Classes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// Title.java
/**
 * Estudiante: Sterlin Lara - 100392179
 * Descripción: Clase que representa la entidad Titles en la base de datos.
 */
public class Title {
    // Campos correspondientes a la tabla Titles en la base de datos
    private String title_id;
    private String title;
    private String type;
    private String pub_id;
    private BigDecimal price;
    private BigDecimal advance;
    private int royalty;
    private int ytd_sales;
    private String notes;
    private Date pubdate;
    
    // Constructor
    public Title(String title_id, String title, String type, String pub_id, BigDecimal price, BigDecimal advance, int royalty, int ytd_sales, String notes, Date pubdate) {
        this.title_id = title_id;
        this.title = title;
        this.type = type;
        this.pub_id = pub_id;
        this.price = price;
        this.advance = advance;
        this.royalty = royalty;
        this.ytd_sales = ytd_sales;
        this.notes = notes;
        this.pubdate = pubdate;
    }
    
    // Getters y Setters
    public String getTitle_id() {
        return title_id;
    }

    public void setTitle_id(String title_id) {
        this.title_id = title_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPub_id() {
        return pub_id;
    }

    public void setPub_id(String pub_id) {
        this.pub_id = pub_id;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getAdvance() {
        return advance;
    }

    public void setAdvance(BigDecimal advance) {
        this.advance = advance;
    }

    public int getRoyalty() {
        return royalty;
    }

    public void setRoyalty(int royalty) {
        this.royalty = royalty;
    }

    public int getYtd_sales() {
        return ytd_sales;
    }

    public void setYtd_sales(int ytd_sales) {
        this.ytd_sales = ytd_sales;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Date getPubdate() {
        return pubdate;
    }

    public void setPubdate(Date pubdate) {
        this.pubdate = pubdate;
    }
    
    // ArrayList para almacenar los títulos
    private static List<Title> titles = new ArrayList<>();

    // Método para crear un nuevo título
    public static void createTitle(Title title) {
        titles.add(title);
    }

    // Método para obtener un título por su ID
    public static Title getTitleById(String title_id) {
        for (Title title : titles) {
            if (title.getTitle_id().equals(title_id)) {
                return title;
            }
        }
        return null; // Si no se encuentra el título
    }

    // Método para actualizar un título existente
    public static void updateTitle(Title updatedTitle) {
        for (int i = 0; i < titles.size(); i++) {
            if (titles.get(i).getTitle_id().equals(updatedTitle.getTitle_id())) {
                titles.set(i, updatedTitle);
                return;
            }
        }
    }

    // Método para eliminar un título por su ID
    public static void deleteTitleById(String title_id) {
        titles.removeIf(title -> title.getTitle_id().equals(title_id));
    }
}
